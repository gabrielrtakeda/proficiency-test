require('./index.styl');

module.exports = angular.module('application', [])
  .controller('IndexApplicationController', require('./IndexApplicationController'))
;
